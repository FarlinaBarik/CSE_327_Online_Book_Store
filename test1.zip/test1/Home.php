<html>
<head>
<title>Bookworms</title>
<h2>Recommended for you </h2>
</head>
<?php
session_start();
$link = mysqli_connect("localhost", "root", "") or die($link);
if($_SESSION['user'])
{
}
else
{
    header("location: Index.php");
}
$user = $_SESSION['user']; //assigns user value
$bool = true;
mysqli_select_db($link,"Online_Bookstore") or die("Cannot connect to database");
//new books recommendation
$query4 = mysqli_query($link,"Select * from Books  ORDER BY Book_id DESC
                       LIMIT 3")  or die( mysqli_error($link)); //recent book suggestion
while($row = mysqli_fetch_array($query4)){
echo "Book name:  " . $row["Title"]
    . "<br>";
    echo "Book Price:  " . $row["Price"]. "<br>";
    echo "Author:  " . $row["Author_name"]. "<br>";


}
$query = mysqli_query($link,"Select * from Customers "); //Query the users table
         $table_cus="";
         while($row = mysqli_fetch_assoc($query)) //display all rows from query
{
$table_cus = $row['User_name'];
    if($table_cus == $user ){
        $customer_id = $row['Customer_id'];
    }

}
$query2 = mysqli_query($link,"Select * from Recommendation "); //Query the users table
          $table_rec="";
while($row = mysqli_fetch_assoc($query2)) //display all rows from query
{
$table_rec = $row['Customer_id'];
    if($table_rec == $customer_id ){
        $bool=false;
    }

}
if($bool){
mysqli_query($link,"INSERT INTO Recommendation (Customer_id,Horror,Cooking,Liturature,Adventure,Mystery,Biography,History,Religion,Romance,Science_fiction,Poetry,Comic,Manga) VALUES ('$customer_id','0','0','0','0','0','0','0','0','0','0','0','0','0')")
    ;
}
?>
<body>
<h2>Home Page</h2>

<p>Hello <?php Print "$user"?>!</p>

<a href="Logout.php">Click here to go logout</a><br/><br/>
 <a href="Profile.php">profile</a><br/><br/>
 <a href="Category.php">Category</a><br/><br/>
<a href="Book.php">Click here to review book</a><br/><br/>
<a href="addtocart.php">Click here to order book</a><br/><br/>
<form action="Home.php" method="post">
 Book name: <input type="text" name="book_name" /> <br/>
 Author<input type="text" name="author" /> <br/>
<input type="submit" value="Search"/>
</form>
<body>
 <?php
$link = mysqli_connect("localhost", "root", "") or die($link);

if($_SERVER["REQUEST_METHOD"] == "POST"){
$book_name =  mysqli_real_escape_string($link,$_POST['book_name']);
    $author =  mysqli_real_escape_string($link,$_POST['author']);
    $user = $_SESSION['user']; //assigns user value
    $bool = true;
    mysqli_select_db($link,"Online_Bookstore") or die("Cannot connect to database");
//search

/**
 * Search books from database according to customers choice.
 *
 * Search based on book title or author name.
 * with while loop it stores all the matching rows
 * 
 * Returns the array.
 * @param string    $book_name  is the book title searched by customer.
 * @param string    $author  is the author name searched by customer.
 * @param string    $link  is the link of the database.
 * @return array returns an array of matched books value.
 * @throws Exception If element is not an integer
 */

function search($book_name,$author,$link){

 $query4 = mysqli_query($link,"Select * from Books  where Books.Title = '$book_name' OR  Books.Author_name = '$author'");
 $resArr[] =array();
    while($row = mysqli_fetch_array($query4)){

 $resArr[] = $row; 
        





    }
return $resArr;

}

 $sideBarPosts = search($book_name,$author,$link); 
foreach($sideBarPosts as $row) { //loop the array
 if(isset($row["Title"])){
 $filename = $row["Title"];
echo "Book name:  " . $filename. "<br>";

}
if(isset($row["Price"])){
 $filename = $row["Price"];
echo "Book Price:  " . $filename. "<br>";
 
}
if(isset($row["Author_name"])){
 $filename = $row["Author_name"];
echo "Author:  " . $filename. "<br>";
 
}
  
        
}
}
?>
</html>

