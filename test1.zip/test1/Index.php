
<html>
    <head>
        <title>Bookworms</title>
    </head>
    <body>
        <?php
            echo "<p>Hello World!</p>";
        ?>
        <a href="Login.php"> Click here to login</a><br/>
        <a href="Register.php"> Click here to register </a>
    </body>
</html> 
